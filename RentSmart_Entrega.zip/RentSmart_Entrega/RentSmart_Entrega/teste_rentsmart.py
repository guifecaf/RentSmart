"""Testes automaticos do sistema RentSmart. Executar: python -m unittest -v"""
import csv
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

from rentsmart import Apartamento, Casa, Estudio, ContratoLocacao


class TesteRentSmart(unittest.TestCase):
    def test_apartamento_base_com_criancas(self):
        self.assertEqual(Apartamento(1, False, True).calcular_orcamento()['aluguel_mensal'], Decimal('700.00'))

    def test_apartamento_com_mais_quarto_garagem_e_desconto(self):
        # (700 + 200 + 300) - 5% = 1.140
        valor = Apartamento(2, True, False).calcular_orcamento()
        self.assertEqual(valor['desconto'], Decimal('60.00'))
        self.assertEqual(valor['aluguel_mensal'], Decimal('1140.00'))

    def test_apartamento_sem_criancas_sem_adicionais(self):
        self.assertEqual(Apartamento(1, False, False).calcular_orcamento()['aluguel_mensal'], Decimal('665.00'))

    def test_casa_com_dois_quartos_e_garagem(self):
        self.assertEqual(Casa(2, True).calcular_orcamento()['aluguel_mensal'], Decimal('1450.00'))

    def test_casa_base(self):
        self.assertEqual(Casa(1, False).calcular_orcamento()['aluguel_mensal'], Decimal('900.00'))

    def test_estudio_sem_estacionamento(self):
        self.assertEqual(Estudio(0).calcular_orcamento()['aluguel_mensal'], Decimal('1200.00'))

    def test_estudio_pacote_duas_vagas(self):
        self.assertEqual(Estudio(2).calcular_orcamento()['aluguel_mensal'], Decimal('1450.00'))

    def test_estudio_com_vagas_adicionais(self):
        self.assertEqual(Estudio(4).calcular_orcamento()['aluguel_mensal'], Decimal('1570.00'))

    def test_estudio_rejeita_uma_vaga(self):
        with self.assertRaises(ValueError):
            Estudio(1)

    def test_quartos_invalidos(self):
        with self.assertRaises(ValueError):
            Casa(3, False)

    def test_parcelas_invalidas(self):
        with self.assertRaises(ValueError):
            ContratoLocacao(Casa(1, False), 6)

    def test_divisao_tres_parcelas_sem_perder_centavos(self):
        contrato = ContratoLocacao(Casa(1, False), 3)
        self.assertEqual(contrato.valores_parcelas(), [Decimal('666.67'), Decimal('666.67'), Decimal('666.66')])
        self.assertEqual(sum(contrato.valores_parcelas()), Decimal('2000.00'))

    def test_projecao_12_meses(self):
        contrato = ContratoLocacao(Apartamento(2, True, False), 5)
        projecao = contrato.projecao()
        self.assertEqual(len(projecao), 12)
        self.assertEqual(projecao[0]['total_mes'], Decimal('1540.00'))
        self.assertEqual(projecao[5]['total_mes'], Decimal('1140.00'))
        self.assertEqual(projecao[-1]['acumulado'], Decimal('15680.00'))

    def test_arquivo_csv(self):
        with tempfile.TemporaryDirectory() as pasta:
            saida = Path(pasta) / 'projecao.csv'
            ContratoLocacao(Casa(2, False), 3).exportar_csv(saida)
            with saida.open(encoding='utf-8-sig', newline='') as arquivo:
                linhas = list(csv.reader(arquivo, delimiter=';'))
            self.assertEqual(len(linhas), 13)  # cabecalho + 12 meses
            self.assertEqual(linhas[1][0], '1')
            self.assertEqual(linhas[1][1], '1150,00')
            self.assertEqual(linhas[3][2], '666,66')
            self.assertEqual(linhas[4][2], '0,00')


if __name__ == '__main__':
    unittest.main()
